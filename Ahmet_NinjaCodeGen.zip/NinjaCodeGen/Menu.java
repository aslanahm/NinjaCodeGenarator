  
import java.util.Scanner;  

public class Menu {  
    int choice;  
    String menu; 
    Scanner s = new Scanner(System.in);
    public void show() {  
       
     System.out.println(" "); 
     System.out.println(" "); 
     System.out.println("\t MAIN MENU ( Enter your Choice )");
     System.out.println(" ");  
     System.out.println("Enter 1 for Help");  
     System.out.println("Enter 2 for About");  
     System.out.println("Enter 3 for Exit");  
     choice = s.nextInt();  
     if (choice == 1) {  
      System.out.println("you have select | Help");
      System.out.println(" loading  Help . . .  ");
      System.out.println(" ");  
      System.out.println("Help Menu:");
      System.out.println(" ");
      System.out.println("Directory Options:");
      System.out.println("-c : creates directory in current location");
      System.out.println("-d : creates directory in your documents folder\n");
      
      System.out.println("Folder Name Options:");
      System.out.println("Folders cannot begin with a number.");
      System.out.println("Cannot have spaces or symbols!");
      System.out.println(" ");
      System.out.println("Site | Files - Options:");
      System.out.println(" ");
      System.out.println("-b : creates a basic site with index.html app.css app.js files.");
      System.out.println("Exa; java NCGMain -c MySite -b ");
      System.out.println("Creates Mysite folder with Basic Site. ");
      System.out.println(" ");
      System.out.println("-t : creates a site template with all files and default layout.");
      System.out.println("Exa; java NCGMain -c MySite -t ");
      System.out.println("Creates Mysite folder with Advenced Templete Site. ");
      System.out.println(" ");
      menu = s.nextLine();  
     }  
     if (choice == 2) {  
      System.out.println("you have select | About");
      System.out.println(" loading  About. . .  ");
      System.out.println(" ");  
      System.out.println("About:");
      System.out.println(" ");
      System.out.println("The purpose of the program is create files and folders"); 
      System.out.println("for based on the selected option -b Basic Site or -t Templete Site.");
      System.out.println("You can try help menu simply use |help| in case your not sure how to navigate in the program.");
      System.out.println("This Java Program was created by Ahmet Aslan in triOS 2020 Copyright.");
      System.out.println(" ");  
      System.out.println(" Starting NCG . . .  ");
      System.out.println(" ");  
      menu = s.nextLine();  
     }  
     if (choice == 3) {  
      System.out.println("you have select  | Exit");
      System.out.println(" Exiting ! ! ! ");
      System.out.println(" ");  
      System.out.println("See you next time!");
      System.exit(0);  
      menu = s.nextLine();  
     }  
    }    
    
     
   }   