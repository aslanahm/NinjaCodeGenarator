
    // Create a new directory 👍
    
    // Create a new file(s)
    // Write to the file (full HTML CSS and JS)
    // Add files to the directory
    
    // take in args from console (folder/project name, location) 👍
    // install on the machine (other peoples machines - Windows)
    // share on GitHub?? (optional)

    // sample command:
    // ncg -c<location> AmazingWebMan<folder name> -b<project type>



    //////////////////////////////////////////////////////////////////////////////
    // Monday Nov 16th of the year that shall not be named.

        - compiled and ran the app from the terminal
        - were able to create NEW directories in a couple locations
        - taken a number of args from the command line
        - setup a decent way to set the directory (still may need work)
        - checking for invalid command line args
        - checked for spaces in project name
        - checked for alphanumeric
        - created a help class (for printing command syntax help)
        - everything is in functions for now
        - still 550,000 lines of code to go (approx.)
        - added this file readme.txt
        - used Bing lots to look up syntax :)
        - we discovered that Java has regualr expressions built-in
        - kicked Monday's butt!



    //////////////////////////////////////////////////////////////////////////////
    // Tuesday Nov 17th of the year that shall not be named.

        - bug fixes/command validation
        - correctly grabs the location
        - correctly set the project type
        - correctly valid the folder name
        - discovered and fixed bug with instantiation.
        - tested and tested and tested and tested...
        - many prints
        - much mess
        - code needs refactor
        - kicked Tuesday's butt!



    //////////////////////////////////////////////////////////////////////////////
    // Wed Nov 18th of the year that shall not be named.

        - some refactoring 👍
        - created a validation class 👍
        - stomped on some bugs that would not go away 🐞



    //////////////////////////////////////////////////////////////////////////////
    // Thurs Nov 19th of the year that shall not be named.

        - squashed 🐞 SetLocation() bugs! 👍
        - created ALL folders - in the correct location! 👍
        - moved arg validation to validator class
        - moved folder creation to its own class
        - renamed Test.java to NCGMain.java (much better) 👍
        // basic folders created - no files created yet!
            - root, assets => images, scripts, css
            - index.html - no design
            - app.css - maybe add a comment
            - app.js - maybe add a comment



    //////////////////////////////////////////////////////////////////////////////
    // Fri Nov 20th of the year that shall not be named.

        - create file(s) w/Code
        - index.html done 👍 app.css app.js not done 👎
        - added a FileCreator class - not fully working for -b AND -t
        - congratulated Rui on his YouTube career!
        
        
        


    //////////////////////////////////////////////////////////////////////////////
    // PROJECT - Due Friday Dec 4th - Presentation Dec 4th (next Friday)

    - you will have a list of arg combos that you will need to test
    // folder
    // -x folder
    // -xyz folder
    // -c -b thanks Rui
    // -c folder name -b
    // must handle any and all combos of commands
    // you may decide if -bbb is an error or accepted


    - kill all 🐛 - I will def test with all arg combos!


    // FileCreator class
        - needs to be fixed
        - must properly create files/folders
          based on projectType - basic or template
        - refactor


    // FolderCreator
        - needs to be fixed
        - must properly create files/folders
          based on projectType - basic or template
        - refactor
    

    // the ability to install PC wide (may need a path variable)
    // look at adding images


    // basic
        - simple index.html, empty css, js, maybe placeholder images


    // template
        - root, assets => images, scripts, css
        - need images! logo placeholder etc...
            OR you could use placehold.it/200x200
        - index.html - mobile responsive site w/header,nav etc...
        - app.css - css required for mobile responsive site
        * jquery.js - for animation (optional)
        - app.js - could have animation for mobile nav
        - css and js files cannot be empty!
        - use may use and modify the BasicTemplate2 (starter site)


    // help system
        - make if pretty and make it understandable!
        - fix this class/refactor add more and improved help system


    *** DUE DATE Friday Dec 4th of the year that shall not be named. ***

    // Optional items
    * ASCII success screen 😸 - bonus marks
    * add a blank line at the top of the files! please! optional
    * GitHub posting // user must have Java (Java Runtime)??