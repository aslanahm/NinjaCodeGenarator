
import javax.swing.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {

    private StringBuilder commandText = new StringBuilder();
    private String[] args;

    public Validator(String[] args) {
        this.args = args;
    }

    public void CheckArgs() {

        // foldername -b
        if(args[0].length() != 2 && args[0].charAt(0) == '-') {
            System.out.println("Happy Coding");
            System.exit(0);
        }
        else if (args.length <= 3 && args.length > 0) {
            for (String arg : args) {
                this.commandText.append(arg);
            }
        }
        else {
            System.out.println("We all having a great day!");
            System.exit(0);
        }
    }
    
    public String CheckLocation() {
        String location = "";
        int dashPos = commandText.indexOf("-");

        if(dashPos < 0) {
            location = "";
        }
        else if(dashPos == 0) {
            location += this.commandText.charAt(0);
            location += this.commandText.charAt(1);
            commandText.delete(dashPos, 2);
        }
        else {
            location = "";
        }

        switch(location) {
            case "help": { // prints directions
                Help help = new Help();
                help.PrintLocationOptions();
                System.exit(0);
            }
            case "": //Empty
            case "-c": { // uses current location
                location = ".//";
                break;
            }
            case "-d": { // documents folder
                location = new JFileChooser().getFileSystemView().getDefaultDirectory().toString() + "\\";
                // System.out.println("from -d");
                break;
            }
            default: { // oops
                location = commandText.toString();
                System.out.println("Command Error. Please make sure you typed correct command");
            }
        } // switch

        return location;
    } // CheckLocation()

    public String CheckType() {
        String projectType = "";
        int dashPos = commandText.indexOf("-");
        
        if(dashPos < 0) {
            projectType = "";
        }
        else if(dashPos > 0) {
            if((commandText.length() - 1) > dashPos) {
                projectType = commandText.substring(dashPos, dashPos + 2);
                commandText.delete(dashPos, commandText.length());
            }
            else {
                Help help = new Help();
                help.PrintTypeOptions();
                System.out.println("this is not fun");
                System.exit(0);
            }
        }
        else {
            projectType += commandText.charAt(commandText.length() - 2);
            projectType += commandText.charAt(commandText.length() - 1);
            commandText.delete(dashPos, commandText.length());
        }

        switch(projectType) {
            case "":
            case "-b": { // basic folder and files - no design
                projectType = "basic";
                System.out.println("You get a simple Basic Site!");
                System.out.println("..............................");
                break;
            }
            case "-t": { // complete template w design etc...
                projectType = "template";
                System.out.println("You get an advanced Templete Site!");
                System.out.println("..................................");
                break;
            }
            default: { // oops
                Help help = new Help();
                help.PrintTypeOptions();
                System.out.println("OOPS! Encountered Wrong Command .Try Again! ");
                System.exit(0);
            }
        } // switch

        return projectType;
    } // CheckType()

    public String CheckFolder() {
        String directoryName = "";
        String folderName = this.commandText.toString();
        Help help = new Help();
        
        // check char[0] not a num
        char firstChar = folderName.charAt(0);
        if(Character.isDigit(firstChar)) {
            help.PrintFolderOptions();
            System.exit(0);
        }

        // check for alphanumeric
        Pattern pattern = Pattern.compile("[a-zA-Z0-9]*");
        Matcher matcher = pattern.matcher(folderName);
    
        if (matcher.matches()) {
            directoryName = folderName;
        } else {
            help.PrintFolderOptions();
            System.exit(0);
        }

        return directoryName;
    } // CheckFolder()

} // Validator()