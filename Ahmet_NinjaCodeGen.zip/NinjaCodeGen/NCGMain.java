import java.io.*;
import java.util.*;
import java.util.Scanner;  
public class NCGMain {

    public static String location = "";
    public static String directoryName = "";
    public static String projectType = "";
    
    public static void main(String[] args) {
        
        Menu m = new Menu();  
        m.show(); 
        Scanner in = new Scanner(System.in);
        
        Console console = System.console();
 
        if (console == null) {
            System.out.println("Console is not supported");
            System.exit(1);
        }
    
        System.out.println(" ");
        System.out.println(" ############## #################################################################### ##############");
        System.out.println(" ############## #################################################################### ##############");
        System.out.println(" ###                                       __,__                                                ###");
        System.out.println(" ###                              .--.  .-\"     \"-.  .--.                                       ###");
        System.out.println(" ###                             / .. \\/  .-. .-.  \\/ .. \\                                      ###");
        System.out.println(" ###                            | |  \'|  /   Y   \\  |\'  | |                                     ###");
        System.out.println(" ###                            | \\   \\  \\ 0 | 0 /  /   / |                                     ###");
        System.out.println(" ###                             \\ \'- ,\\.-\"`` ``\"-./, -\' /                                      ###");
        System.out.println(" ###                              `\'-\' /_   ^ ^   _\\ \'-\'`                                       ###");
        System.out.println(" ###                              .--\'|  \\._ _ _./  |\'--.                                       ###");
        System.out.println(" ###                            /`    \\   \\.-.  /   /    `\\                                     ###");
        System.out.println(" ###                           /       \'._/  |-\' _.\'       \\                                    ###");
        System.out.println(" ###                          /          ;  /--~\'   |       \\                                   ###");
        System.out.println(" ###                         /        .\'\\|.-\\--.     \\       \\                                  ###");
        System.out.println(" ###                        /   .\'-. /.-.;\\  |\\|\'~\'-.|\\       \\                                 ###");
        System.out.println(" ###                        \\       `-./`|_\\_/ `     `\\\'.      \\                                ###");
        System.out.println(" ###                         \'.      ;     ___)        \'.`;    /  /\'\'\'\'\'\'\\                      ###");
        System.out.println(" ###                           \'-.,_ ;     ___)          \\/   /  /  ___   \\                     ###");
        System.out.println(" ###                            \\   ``\'------\'\\       \\   `  /  /  /   \\   \\                    ###");
        System.out.println(" ###                             \'.    \\       \'.      |   ;/__/  /     \\   \\                   ###");
        System.out.println(" ###                           ___>     \'.       \\_ _ _/   ,     /       \\__/                   ###");
        System.out.println(" ###                         .\'   \'.   .''''''''/    |--\'`~~~~\'\'                                ###");
        System.out.println(" ###                   _____// / .---\'        _/ / / /__  _____  _____  _____                   ###");
        System.out.println(" ###                  | ___((_(_/  (_)       |(_(_(_|___|/  __ \\|_   _||_   _|                  ###");
        System.out.println(" #####        -------------------------------------------------------------------------       #####");
        System.out.println(" ###                             NINJA CODE GENERATOR 2020 triOS                                ###");
        System.out.println(" ####                                                                                          ####");
        System.out.println(" ###                                 CREATED BY AHMET ASLAN                                     ###");
        System.out.println(" ###                                                                                            ###");
        System.out.println(" ###          -------------------------------------------------------------------------         ###");
        System.out.println(" ###          |                         NCG INSTRUCTIONS                              |         ###");
        System.out.println(" ###          |-----------------------------------------------------------------------|         ###");
        System.out.println(" ###          |      1) -c : creates directory in current location                    |         ###");
        System.out.println(" ###          |                e.g. C:\\someFolder\\file.txt                            |         ###");
        System.out.println(" ###          |		                                                              |         ###");
        System.out.println(" ###          |      2) Type the command: java NCGMain -c Mysite -b for Basic Site    |         ###");
        System.out.println(" ###          |        OR java NCGMain -c Mysite -t for Advenced Templete Site        |         ###");
        System.out.println(" ###          |                                                                       |         ###");
        System.out.println(" ###          |      3) -d : creates directory in your documents folder               |         ###");
        System.out.println(" ###          |            e.g. C:\\Documents\\giveFileName.txt                         |         ###");
        System.out.println(" ###          |                                                                       |         ###");
        System.out.println(" ###          |      4) empty entry is also creates Basic Site                        |         ###");
        System.out.println(" ###          -------------------------------------------------------------------------         ###");
        System.out.println(" ###                                                                                            ###");
        System.out.println(" ##################################################################################################");
        System.out.println(" ##################################################################################################");
         
        System.out.println(" ");
        console.printf("\t\t\t Welcome to Java Ninja Code Generator Program!\n");
        System.out.println(" ");
        System.out.println(" Lets Get You Started...Please Login Your NCG Account !");
        System.out.println(" ");
        String name = console.readLine("Enter your name: ");
        System.out.println(" ____________________________________________ ");
        System.out.println("|(Password Hint: type triOS -Case Sensetive!)| ");
        System.out.println("|____________________________________________| ");
        char[] password = console.readPassword("Enter your password: ");

        char[] correctPassword = {'t', 'r', 'i', 'O', 'S'};
        
        if (Arrays.equals(password, correctPassword)) {
            console.printf("Thanks %s, you are logged in.\n", name);
            System.out.println("-------------------------------------------------- ");
            System.out.println("|Please visit Help Menu/Instructions for commands|"); 
            System.out.println("-------------------------------------------------- ");
            console.readLine("Enter your command: "); 
        } else {
            console.printf("Sorry, you are denied.Try Again!\n");
            System.out.println("oOoOoOoOoOoOoOoOoO ");
            System.out.println("Exiting NCG! ... ");  
        }
 
        Arrays.fill(password, ' ');
        Arrays.fill(correctPassword, ' ');

        Validator validator = new Validator(args);
        validator.CheckArgs();
        location = validator.CheckLocation();
        projectType = validator.CheckType();
        directoryName = validator.CheckFolder();

        //////////////////////////////////////////
        // Folder(s) Creation
        FolderCreator folderCreator = new FolderCreator(location, directoryName);
        System.out.println(folderCreator.GenerateFolders());

        //////////////////////////////////////////
        // File(s) Creation // app.css app.js
        FileCreator fileCreator = new FileCreator(projectType);
        
        if(projectType.equals("basic")) {
            fileCreator.ReadFile("./basicCodeFiles/index.html");
            fileCreator.CreateFile(location + directoryName + "/index.html");
            fileCreator.CreateFile(location + directoryName + "/css/app.css");
            fileCreator.CreateFile(location + directoryName + "/scripts/app.js");
            fileCreator.CreateFile(location + directoryName + "/assets/images/placehold.it/200x200");
        }
        else {
            fileCreator.ReadFile("./templateCodeFiles/index.html");
            fileCreator.CreateFile(location + directoryName + "/index.html");
            fileCreator.ReadFile("./templateCodeFiles/css/app.css");
            fileCreator.CreateFile(location + directoryName + "/css/app.css");
            fileCreator.ReadFile("./templateCodeFiles/scripts/app.js");
            fileCreator.CreateFile(location + directoryName + "/scripts/app.js");
            fileCreator.ReadFile("./templateCodeFiles/scripts/jquery.js");
            fileCreator.CreateFile(location + directoryName + "/scripts/jquery.js");
        }

        //Start OVer
        Boolean play = true;
        while (play) {
            //  code here

            System.out.println("Would you like to start over again Y/N?");
            play = in.nextLine().trim().equalsIgnoreCase("y"); // "y" will set 'start over' to 'true', anything else will set it to 'false'
}
    } // main
} // class